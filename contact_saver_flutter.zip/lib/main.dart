import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:pdf_text/pdf_text.dart';
import 'package:archive/archive_io.dart';
import 'package:xml/xml.dart' as xml;
import 'package:flutter_contacts/flutter_contacts.dart';

void main() {
  runApp(ContactSaverApp());
}

class ContactSaverApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contact Saver',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: ContactSaverScreen(),
    );
  }
}

class ContactItem {
  String name;
  String phone;
  bool saved;
  ContactItem({required this.name, required this.phone, this.saved = false});
}

class ContactSaverScreen extends StatefulWidget {
  @override
  _ContactSaverScreenState createState() => _ContactSaverScreenState();
}

class _ContactSaverScreenState extends State<ContactSaverScreen> {
  final TextEditingController countryCodeController =
      TextEditingController(text: '+98');
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();

  List<ContactItem> extracted = [];

  bool isProcessing = false;

  final RegExp phoneRegex =
      RegExp(r'(\+?\d[\d\-\s\(\)]{5,}\d)', multiLine: true);

  String normalizePhone(String raw, String defaultCountryCode) {
    raw = raw.trim();
    bool hasPlus = raw.startsWith('+');
    String digits = raw.replaceAll(RegExp(r'[^\d+]'), '');
    if (!hasPlus) {
      if (!digits.startsWith(defaultCountryCode.replaceAll('+', ''))) {
        if (digits.startsWith('0')) digits = digits.substring(1);
        digits = defaultCountryCode + digits;
        if (!digits.startsWith('+')) digits = '+' + digits.replaceAll('+', '');
      } else {
        if (!digits.startsWith('+')) digits = '+' + digits.replaceAll('+', '');
      }
    } else {
      digits = '+' + digits.replaceAll('+', '');
    }
    return digits;
  }

  Future<String> _readTxt(File file) async {
    return await file.readAsString();
  }

  Future<String> _readPdf(File file) async {
    try {
      PDFDoc doc = await PDFDoc.fromFile(file);
      String text = await doc.text;
      return text;
    } catch (e) {
      print('PDF read error: \$e');
      return '';
    }
  }

  Future<String> _readDocx(File file) async {
    try {
      final bytes = await file.readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes, verify: true);
      for (final file in archive) {
        if (file.name == 'word/document.xml') {
          final data = file.content as List<int>;
          final xmlString = String.fromCharCodes(data);
          final document = xml.XmlDocument.parse(xmlString);
          final textNodes = document.findAllElements('t', namespace: '*');
          final buffer = StringBuffer();
          for (var node in textNodes) {
            buffer.write(node.text);
            buffer.write(' ');
          }
          return buffer.toString();
        }
      }
      return '';
    } catch (e) {
      print('DOCX read error: \$e');
      return '';
    }
  }

  void _extractFromText(String text, String defaultCountryCode) {
    final matches = phoneRegex.allMatches(text);
    setState(() {
      for (final m in matches) {
        final raw = m.group(0) ?? '';
        String normalized = normalizePhone(raw, defaultCountryCode);
        final digitsOnly = normalized.replaceAll(RegExp(r'[^\d+]'), '');
        if (digitsOnly.replaceAll('+', '').length >= 7 &&
            !extracted.any((e) => e.phone == normalized)) {
          extracted.add(ContactItem(name: 'نام وارد نشده', phone: normalized));
        }
      }
    });
  }

  Future<void> pickFiles() async {
    setState(() {
      isProcessing = true;
    });

    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['txt', 'pdf', 'docx', 'doc'],
      withData: false,
    );

    if (result == null) {
      setState(() {
        isProcessing = false;
      });
      return;
    }

    for (final f in result.files) {
      try {
        if (f.path == null) continue;
        final file = File(f.path!);
        final ext = f.extension?.toLowerCase();
        String content = '';
        if (ext == 'txt') {
          content = await _readTxt(file);
        } else if (ext == 'pdf') {
          content = await _readPdf(file);
        } else if (ext == 'docx') {
          content = await _readDocx(file);
        } else if (ext == 'doc') {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text(
                  'فایل \${f.name} فرمت .doc است — لطفاً به docx یا pdf تبدیل کنید.')));
          continue;
        } else {
          continue;
        }

        if (content.trim().isNotEmpty) {
          _extractFromText(content, countryCodeController.text);
        }
      } catch (e) {
        print('File processing error for \${f.name}: \$e');
      }
    }

    setState(() {
      isProcessing = false;
    });
  }

  void addManual() {
    final name = nameController.text.trim();
    final phone = phoneController.text.trim();
    if (phone.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('شماره تلفن را وارد کنید')));
      return;
    }
    final normalized = normalizePhone(phone, countryCodeController.text);
    setState(() {
      extracted.add(ContactItem(
          name: name.isEmpty ? 'نام وارد نشده' : name, phone: normalized));
      nameController.clear();
      phoneController.clear();
    });
  }

  Future<bool> _ensureContactsPermission() async {
    if (await FlutterContacts.requestPermission()) {
      return true;
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('نیاز به اجازهٔ دسترسی به مخاطبین است')));
      return false;
    }
  }

  Future<void> saveContact(ContactItem item) async {
    final ok = await _ensureContactsPermission();
    if (!ok) return;

    final contact = Contact();
    contact.name.first = item.name;
    contact.phones = [Phone(item.phone)];
    try {
      await FlutterContacts.insert(contact);
      setState(() {
        item.saved = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('ذخیره شد: \${item.name} — \${item.phone}')));
    } catch (e) {
      print('Save contact error: \$e');
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطا در ذخیره مخاطب: \${e.toString()}')));
    }
  }

  Future<void> saveAll() async {
    final ok = await _ensureContactsPermission();
    if (!ok) return;

    int count = 0;
    for (final item in extracted) {
      if (!item.saved) {
        final contact = Contact();
        contact.name.first = item.name;
        contact.phones = [Phone(item.phone)];
        try {
          await FlutterContacts.insert(contact);
          item.saved = true;
          count++;
        } catch (e) {
          print('Save contact error: \$e');
        }
      }
    }
    setState(() {});
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text('تعداد ذخیره‌شده: \$count')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contact Saver — استخراج و ذخیره شماره'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: SingleChildScrollView(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(
              controller: countryCodeController,
              decoration: InputDecoration(labelText: 'کد کشور (مثال: +98)'),
            ),
            SizedBox(height: 12),
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'نام کاربر'),
            ),
            SizedBox(height: 12),
            TextField(
              controller: phoneController,
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(labelText: 'شماره تلفن (دستی)'),
            ),
            SizedBox(height: 12),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: addManual,
                  icon: Icon(Icons.person_add),
                  label: Text('افزودن دستی'),
                ),
                SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: isProcessing ? null : pickFiles,
                  icon: Icon(Icons.upload_file),
                  label: Text(isProcessing
                      ? 'در حال پردازش...'
                      : 'انتخاب فایل (TXT, PDF, DOCX)'),
                  style:
                      ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                ),
              ],
            ),
            SizedBox(height: 18),
            Text(
              'پیش‌نمایش شماره‌ها:',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            extracted.isEmpty
                ? Text('هیچ شماره‌ای یافت نشد.')
                : ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: extracted.length,
                    itemBuilder: (context, i) {
                      final it = extracted[i];
                      return Card(
                        child: ListTile(
                          title: Text(it.name),
                          subtitle: Text(it.phone),
                          leading: it.saved
                              ? Icon(Icons.check_circle, color: Colors.green)
                              : Icon(Icons.phone),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                icon: Icon(Icons.save, color: Colors.green),
                                onPressed: it.saved ? null : () => saveContact(it),
                              ),
                              IconButton(
                                icon: Icon(Icons.delete, color: Colors.red),
                                onPressed: () {
                                  setState(() {
                                    extracted.removeAt(i);
                                  });
                                },
                              ),
                            ],
                          ),
                          onTap: () async {
                            final newName = await showDialog<String>(
                                context: context,
                                builder: (ctx) {
                                  final c = TextEditingController(text: it.name);
                                  return AlertDialog(
                                    title: Text('ویرایش نام'),
                                    content: TextField(
                                      controller: c,
                                      decoration:
                                          InputDecoration(labelText: 'نام'),
                                    ),
                                    actions: [
                                      TextButton(
                                          onPressed: () =>
                                              Navigator.of(ctx).pop(null),
                                          child: Text('انصراف')),
                                      ElevatedButton(
                                          onPressed: () =>
                                              Navigator.of(ctx).pop(c.text),
                                          child: Text('ذخیره')),
                                    ],
                                  );
                                });
                            if (newName != null && newName.trim().isNotEmpty) {
                              setState(() {
                                it.name = newName.trim();
                              });
                            }
                          },
                        ),
                      );
                    },
                  ),
            SizedBox(height: 18),
            ElevatedButton.icon(
              onPressed: extracted.isEmpty ? null : saveAll,
              icon: Icon(Icons.save),
              label: Text('ذخیره همه در مخاطبین'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
            ),
            SizedBox(height: 12),
            Text(
              'توجه: فایل‌های .doc (قدیمی) ممکن است پشتیبانی نشوند — لطفاً در صورت امکان به .docx یا .pdf تبدیل کنید.',
              style: TextStyle(color: Colors.grey[700]),
            ),
          ]),
        ),
      ),
    );
  }
}